var bar = (function () {
    function foo (bar) {
        return bar;
    }

    return foo;
})();
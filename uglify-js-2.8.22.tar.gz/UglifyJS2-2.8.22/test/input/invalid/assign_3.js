console.log(3 || ++this);
